/**
 * Includes all blocks root files
 */
import './shortcode/index';